export const LICENSED_ROLE_FILTER = 'licensedRole';
